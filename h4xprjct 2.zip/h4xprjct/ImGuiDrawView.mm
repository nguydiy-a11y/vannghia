// Require standard library
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#include <iostream>
#include <UIKit/UIKit.h>
#include <vector>
#import "pthread.h"
#include <array>
#import <os/log.h>
#include <cmath>
#include <deque>
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdint>
#include <cinttypes>
#include <cerrno>
#include <cctype>
#import <substrate.h>  // ضروري لـ MSHookFunction

// ImGui library
#import "Esp/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_internal.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/zzz.h"
#include "oxorany/oxorany_include.h"
#import "Helper/Mem.h"
#include "font.h"
#import "Helper/Vector3.h"
#import "Helper/Vector2.h"
#import "Helper/Quaternion.h"
#import "Helper/Monostring.h"
#include "Helper/font.h"
#include "Helper/data.h"

#include "Helper/Obfuscate.h"
#import "Helper/Hooks.h"
// Déclaration de la fonction 'hook' pour résoudre l'erreur de l'identifiant non déclaré
extern "C" void hook(void** addresses, void** functions, int count);

// Déclaration de la variable 'camxa' pour résoudre l'erreur de type dans ImGui::Checkbox
bool camxa = false;
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>
#include <ctime>    // لـ time()

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

ImFont* verdana_smol = nullptr;
ImFont* pixel_big = nullptr;
ImFont* pixel_smol = nullptr;

@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

@implementation ImGuiDrawView

ImFont *_espFont = nullptr;
ImFont* verdanab = nullptr;
ImFont* icons = nullptr;
ImFont* interb = nullptr;
ImFont* Urbanist = nullptr;

static bool MenDeal = true;
static float networkColor[3] = {1.0f, 1.0f, 1.0f};
static int style_idx = 0; // تم تعريف المتغير المفقود هنا

bool rsttk = false;
bool Guest(void* _this){
    if (rsttk){
      return true;
    } else { return true; 
}
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _device = MTLCreateSystemDefaultDevice();
        _commandQueue = [_device newCommandQueue];

        if (!_device) {
            abort();
        }

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO(); (void)io;

        ImGuiStyle& style = ImGui::GetStyle();
        
        // Modern Professional Style
        style.WindowRounding = 10.0f;
        style.FrameRounding = 6.0f;
        style.ChildRounding = 8.0f;
        style.PopupRounding = 8.0f;
        style.ScrollbarRounding = 12.0f;
        style.GrabRounding = 6.0f;
        style.TabRounding = 6.0f;
        
        style.WindowPadding = ImVec2(15, 15);
        style.FramePadding = ImVec2(6, 6);
        style.ItemSpacing = ImVec2(10, 10);
        style.WindowBorderSize = 1.0f;
        style.ChildBorderSize = 1.0f;

        ImVec4* colors = style.Colors;
        
        // Custom Professional Theme (Deep Charcoal & Electric Blue)
        colors[ImGuiCol_Text]                   = ImVec4(0.95f, 0.96f, 0.98f, 1.00f);
        colors[ImGuiCol_TextDisabled]           = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
        colors[ImGuiCol_WindowBg]               = ImVec4(0.11f, 0.11f, 0.14f, 0.98f);
        colors[ImGuiCol_ChildBg]                = ImVec4(0.15f, 0.15f, 0.18f, 0.00f);
        colors[ImGuiCol_PopupBg]                = ImVec4(0.11f, 0.11f, 0.14f, 0.94f);
        colors[ImGuiCol_Border]                 = ImVec4(0.25f, 0.25f, 0.28f, 0.50f);
        colors[ImGuiCol_FrameBg]                = ImVec4(0.18f, 0.18f, 0.22f, 1.00f);
        colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.25f, 0.25f, 0.30f, 1.00f);
        colors[ImGuiCol_FrameBgActive]          = ImVec4(0.30f, 0.30f, 0.35f, 1.00f);
        colors[ImGuiCol_TitleBg]                = ImVec4(0.11f, 0.11f, 0.14f, 1.00f);
        colors[ImGuiCol_TitleBgActive]          = ImVec4(0.14f, 0.14f, 0.18f, 1.00f);
        colors[ImGuiCol_CheckMark]              = ImVec4(0.00f, 0.60f, 1.00f, 1.00f);
        colors[ImGuiCol_SliderGrab]             = ImVec4(0.00f, 0.60f, 1.00f, 1.00f);
        colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.00f, 0.70f, 1.00f, 1.00f);
        colors[ImGuiCol_Button]                 = ImVec4(0.20f, 0.20f, 0.25f, 1.00f);
        colors[ImGuiCol_ButtonHovered]          = ImVec4(0.25f, 0.25f, 0.35f, 1.00f);
        colors[ImGuiCol_ButtonActive]           = ImVec4(0.00f, 0.60f, 1.00f, 1.00f);
        colors[ImGuiCol_Header]                 = ImVec4(0.20f, 0.20f, 0.25f, 1.00f);
        colors[ImGuiCol_HeaderHovered]          = ImVec4(0.25f, 0.25f, 0.35f, 1.00f);
        colors[ImGuiCol_HeaderActive]           = ImVec4(0.00f, 0.60f, 1.00f, 1.00f);
        colors[ImGuiCol_Tab]                    = ImVec4(0.15f, 0.15f, 0.18f, 1.00f);
        colors[ImGuiCol_TabHovered]             = ImVec4(0.25f, 0.25f, 0.35f, 1.00f);
        colors[ImGuiCol_TabActive]              = ImVec4(0.00f, 0.60f, 1.00f, 1.00f);

        // الخطوط
        io.Fonts->AddFontFromMemoryTTF(sansbold, sizeof(sansbold), 15.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
        verdana_smol = io.Fonts->AddFontFromMemoryTTF(verdana, sizeof(verdana), 40.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
        pixel_big    = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof(smallestpixel), 128.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
        pixel_smol   = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof(smallestpixel), 20.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());

        ImGui_ImplMetal_Init(_device);
    }
    return self;
}

+ (void)showChange:(BOOL)open {
    MenDeal = open;
}

- (MTKView *)mtkView {
    return (MTKView *)self.view;
}

- (void)loadView {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    CGFloat w = keyWindow.rootViewController.view.frame.size.width;
    CGFloat h = keyWindow.rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];

    void* address[] = {
        (void*)getRealOffset(0x100FD150C),
    };
    void* function[] = {
        (void*)Guest,
    };
    hook(address, function, 1);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor clearColor];
    self.mtkView.clipsToBounds = YES;
}

#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event {
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.AddMousePosEvent(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) {
            hasActiveTouch = YES;
            break;
        }
    }
    io.AddMouseButtonEvent(0, hasActiveTouch);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

#pragma mark - Drawing Functions

void DrawMovingWeb(ImDrawList* drawList, ImVec2 menuPos, ImVec2 menuSize) {
    // Keep original logic but with subtle colors
    static std::vector<ImVec2> nodes;
    static std::vector<ImVec2> velocities;
    // static float timeElapsed = 0.0f; // Not used
    
    float maxDistance = 100.0f;
    float speed = 0.4f;
    ImVec2 menuEnd = ImVec2(menuPos.x + menuSize.x, menuPos.y + menuSize.y);

    if (nodes.empty()) {
        srand((unsigned)time(NULL));
        for (int i = 0; i < 12; i++) {
            nodes.push_back(ImVec2(menuPos.x + (rand() % (int)menuSize.x), menuPos.y + (rand() % (int)menuSize.y)));
            velocities.push_back(ImVec2((rand() % 100 - 50) / 100.0f * speed, (rand() % 100 - 50) / 100.0f * speed));
        }
    }

    for (size_t i = 0; i < nodes.size(); i++) {
        nodes[i] += velocities[i];
        if (nodes[i].x <= menuPos.x || nodes[i].x >= menuEnd.x) velocities[i].x *= -1;
        if (nodes[i].y <= menuPos.y || nodes[i].y >= menuEnd.y) velocities[i].y *= -1;
    }

    for (size_t i = 0; i < nodes.size(); i++) {
        for (size_t j = i + 1; j < nodes.size(); j++) {
            float dist = sqrtf(ImLengthSqr(nodes[i] - nodes[j]));
            if (dist < maxDistance) {
                drawList->AddLine(nodes[i], nodes[j], ImColor(0, 150, 255, (int)((1.0f - dist / maxDistance) * 100)), 1.0f);
            }
        }
    }
}

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(view.bounds.size.width, view.bounds.size.height);

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1.0f / (view.preferredFramesPerSecond ?: 60);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    
    view.userInteractionEnabled = MenDeal;

    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil) {
        id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@"ImGui Render"];

        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();

        UIWindow *mainWindow = UIApplication.sharedApplication.keyWindow;
        CGFloat x = (mainWindow.bounds.size.width - 450) / 2;
        CGFloat y = (mainWindow.bounds.size.height - 350) / 2;

        ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(450, 350), ImGuiCond_FirstUseEver);

        if (MenDeal == true) {
            char* Gnam = (char*) [[NSString stringWithFormat:@"%s", oxorany("OSM X DLVXX 1.118.X ")] cStringUsingEncoding:NSUTF8StringEncoding];
            ImGui::Begin(Gnam, &MenDeal, ImGuiWindowFlags_AlwaysAutoResize);
            ImGui::PushItemWidth(ImGui::GetWindowWidth() * 0.55f);

            if (ImGui::BeginTabBar(oxorany("Bar"), ImGuiTabBarFlags_NoTooltip)) {
                if (ImGui::BeginTabItem(oxorany(ICON_FA_CROSSHAIRS "AimBot"))) {
                    ImGui::Checkbox(oxorany("Enable Aimbot"), &Vars.Aimbot);
                    ImGui::Separator();
                    ImGui::SliderFloat("Aim FOV", &Vars.AimFov, 0.0f, 500.0f);
                    ImGui::Text(oxorany("Aim Fov"));
                    ImGui::SliderFloat(oxorany("##circle"), &Vars.AimFov, 0.0f, 360.0f);
                    const char* aimWhenOptions[] = {"Auto Aim", "Fire + Scope", "Scope"};
                    ImGui::Combo("Aim When", &Vars.AimWhen, aimWhenOptions, IM_ARRAYSIZE(aimWhenOptions));
                    ImGui::Checkbox("SHOW FOV", &Vars.fovaimglow);
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(oxorany(ICON_FA_EYE " Esp"))){
                    ImGui::Spacing();
                    ImGui::Checkbox(oxorany("Enable Esp"), &Vars.Enable);
                    ImGui::Separator();
                    ImGui::Checkbox(oxorany("Esp - Lines"), &Vars.lines);
                    ImGui::Checkbox(oxorany("Esp - Boxes"), &Vars.Box);
                    ImGui::Checkbox(oxorany("Esp - Name"), &Vars.Name);
                    ImGui::Checkbox(oxorany("Esp - Health"), &Vars.Health);
                    ImGui::Checkbox(oxorany("Esp - Enemy Count"), &Vars.Health);
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(oxorany(ICON_FA_COGS " Settings"))){
                    ImGui::Spacing();
                    ImGui::Checkbox(oxorany("Guest Reset"), &rsttk);
                    ImGui::Spacing();
                    if (ImGui::Combo(oxorany("Color Menu"), &style_idx, "Dark\0Light\0Classic\0")) {
                        switch (style_idx) {
                            case 0: ImGui::StyleColorsDark(); break;
                            case 1: ImGui::StyleColorsLight(); break;
                            case 2: ImGui::StyleColorsClassic(); break;
                        }
                    }
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(oxorany(ICON_FA_ADDRESS_CARD "InFo"))) {
                    ImGui::SeparatorText(oxorany("Contact US"));
                    ImGui::TextDisabled(oxorany("Developer:"));
                    ImGui::SameLine();
                    ImGui::EndTabItem();
                }
                ImGui::EndTabBar();
            }
            ImGui::End();
        }

        get_players();
        draw_watermark();
        aimbot();
        game_sdk->init();
        Vars.isAimFov = (Vars.AimFov > 0.0f);

        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);

        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];

        [commandBuffer presentDrawable:view.currentDrawable];
    }

    [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {
    // غير مطلوب عادة
}

@end
