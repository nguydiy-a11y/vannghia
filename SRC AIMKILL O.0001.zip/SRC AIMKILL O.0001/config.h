// --- config.h ---
#pragma once
struct Variables {
    bool air, under, ninja, tele_vi, telekill, aimkill_vi, aim_kill, fake_lag, ghost, fly, fly_altura;
} cfg;

// --- offset.h ---
#pragma once
#include <cstdint>
namespace Offsets {
    constexpr uintptr_t GWorld = 0x76A8B40;
    constexpr uintptr_t SetControlRotation = 0x76B2A10;
    constexpr uintptr_t CharacterMovement = 0x320;
    constexpr uintptr_t MaxWalkSpeed = 0x1A0;
    constexpr uintptr_t GravityScale = 0x300;
    constexpr uintptr_t SetActorLocation = 0x78C3D40;
    constexpr uintptr_t bActorEnableCollision = 0x5C;
}

// --- memory.h ---
#pragma once
#include <sys/mman.h>
#include <unistd.h>
#include <vector>
#include <string>
namespace Memory {
    uintptr_t GetBaseAddress(const char* name) {
        uintptr_t base = 0;
        char line[512];
        FILE* f = fopen("/proc/self/maps", "r");
        if (!f) return 0;
        while (fgets(line, sizeof(line), f)) {
            if (strstr(line, name)) {
                base = strtoull(line, NULL, 16);
                break;
            }
        }
        fclose(f);
        return base;
    }
    void PatchHex(uintptr_t address, std::string hex) {
        std::vector<unsigned char> bytes;
        for (unsigned int i = 0; i < hex.length(); i += 2) {
            bytes.push_back((unsigned char)strtol(hex.substr(i, 2).c_str(), NULL, 16));
        }
        unsigned long page_size = sysconf(_SC_PAGESIZE);
        mprotect((void*)(address & ~(page_size - 1)), page_size, PROT_READ | PROT_WRITE | PROT_EXEC);
        memcpy((void*)address, bytes.data(), bytes.size());
    }
}

// --- menu.cpp ---
#include "imgui.h"
#include "imgui_internal.h"
#include "config.h"
void DrawAndroidToggle(const char* label, bool* v, ImU32 activeColor) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    const ImGuiID id = window->GetID(label);
    ImVec2 p = window->DC.CursorPos;
    float w = ImGui::GetContentRegionAvail().x, h = 55.0f;
    ImRect bb(p, ImVec2(p.x + w, p.y + h));
    ImGui::ItemSize(bb);
    if (!ImGui::ItemAdd(bb, id)) return;
    if (ImGui::ButtonBehavior(bb, id, NULL, NULL)) *v = !(*v);
    window->DrawList->AddRect(p, ImVec2(p.x + w, p.y + h), activeColor, h/2, 0, 2.5f);
    window->DrawList->AddRectFilled(p, ImVec2(p.x + w, p.y + h), ImColor(15, 15, 15, 220), h/2);
    window->DrawList->AddText(ImVec2(p.x + 25, p.y + h/2 - 10), ImColor(255, 255, 255), label);
    float sw_w = 70.0f, sw_h = 35.0f;
    ImVec2 sw_p(p.x + w - sw_w - 15, p.y + h/2 - sw_h/2);
    window->DrawList->AddRectFilled(sw_p, ImVec2(sw_p.x + sw_w, sw_p.y + sw_h), *v ? activeColor : ImColor(60, 60, 60), sw_h/2);
    window->DrawList->AddCircleFilled(ImVec2(*v ? sw_p.x + sw_w - 18 : sw_p.x + 18, sw_p.y + sw_h/2), 12.0f, ImColor(255, 255, 255));
}
void RenderMonalisaMenu() {
    ImGui::SetNextWindowSize(ImVec2(500, 750));
    ImGui::Begin("MONALISA_VIP", nullptr, ImGuiWindowFlags_NoTitleBar);
    DrawAndroidToggle("Air", &cfg.air, ImColor(0, 255, 255)); ImGui::Spacing();
    DrawAndroidToggle("Under", &cfg.under, ImColor(0, 255, 255)); ImGui::Spacing();
    DrawAndroidToggle("Ninja", &cfg.ninja, ImColor(255, 0, 255)); ImGui::Spacing();
    DrawAndroidToggle("Tele vi", &cfg.tele_vi, ImColor(255, 165, 0)); ImGui::Spacing();
    DrawAndroidToggle("Telekill", &cfg.telekill, ImColor(255, 0, 0)); ImGui::Spacing();
    DrawAndroidToggle("AimKillvi", &cfg.aimkill_vi, ImColor(255, 0, 100)); ImGui::Spacing();
    DrawAndroidToggle("AimKill", &cfg.aim_kill, ImColor(255, 0, 0)); ImGui::Spacing();
    DrawAndroidToggle("Fake Lag", &cfg.fake_lag, ImColor(255, 0, 0)); ImGui::Spacing();
    DrawAndroidToggle("Ghost", &cfg.ghost, ImColor(0, 255, 0)); ImGui::Spacing();
    DrawAndroidToggle("Fly", &cfg.fly, ImColor(0, 255, 0)); ImGui::Spacing();
    DrawAndroidToggle("Fly Altura", &cfg.fly_altura, ImColor(255, 0, 0));
    ImGui::End();
}

// --- main.cpp ---
#include <pthread.h>
#include "offset.h"
#include "config.h"
#include "memory.h"
void* HackThread(void*) {
    uintptr_t base = 0;
    while (!(base = Memory::GetBaseAddress("libil2cpp.so"))) sleep(1);
    while (true) {
        if (cfg.fly) Memory::PatchHex(base + Offsets::GravityScale, "000080D2C0035FD6");
        if (cfg.ninja) Memory::PatchHex(base + Offsets::MaxWalkSpeed, "400680D2C0035FD6");
        if (cfg.ghost) Memory::PatchHex(base + Offsets::bActorEnableCollision, "1F2003D5");
        usleep(500000);
    }
    return nullptr;
}
extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    pthread_t ptid;
    pthread_create(&ptid, NULL, HackThread, NULL);
    return JNI_VERSION_1_6;
}
