#pragma once
#include <sys/mman.h>
#include <unistd.h>
#include <vector>
#include <string>
#include <iostream>

namespace Memory {
    uintptr_t GetBaseAddress(const char* name) {
        uintptr_t base = 0;
        char line[512];
        FILE* f = fopen("/proc/self/maps", "r");
        if (!f) return 0;
        while (fgets(line, sizeof(line), f)) {
            if (strstr(line, name)) {
                base = strtoull(line, NULL, 16);
                break;
            }
        }
        fclose(f);
        return base;
    }

    bool Write(uintptr_t address, void* buffer, size_t size) {
        if (!address) return false;
        unsigned long page_size = sysconf(_SC_PAGESIZE);
        uintptr_t page_start = address & ~(page_size - 1);
        if (mprotect((void*)page_start, page_size, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) return false;
        memcpy((void*)address, buffer, size);
        return true;
    }

    void PatchHex(uintptr_t address, std::string hex) {
        if (!address) return;
        std::vector<unsigned char> bytes;
        for (unsigned int i = 0; i < hex.length(); i += 2) {
            std::string byteString = hex.substr(i, 2);
            unsigned char byte = (unsigned char)strtol(byteString.c_str(), NULL, 16);
            bytes.push_back(byte);
        }
        Write(address, bytes.data(), bytes.size());
    }

    template <typename T>
    T Read(uintptr_t address) {
        T buffer;
        if (!address) return buffer;
        memcpy(&buffer, (void*)address, sizeof(T));
        return buffer;
    }

    template <typename T>
    void WriteValue(uintptr_t address, T value) {
        if (!address) return;
        Write(address, &value, sizeof(T));
    }
}
