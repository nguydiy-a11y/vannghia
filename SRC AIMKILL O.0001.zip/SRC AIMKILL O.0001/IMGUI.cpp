#include <jni.h>
#include <string>
#include <vector>
#include <cmath>
#include "imgui.h"

// --- [ CONFIGURATION STORAGE ] ---
struct {
    bool air = false;
    bool under = false;
    bool ninja = false;
    bool tele_vi = false;
    bool telekill = false;
    bool aimkill_vi = false;
    bool aim_kill = false;
    bool fake_lag = false;
    bool ghost = false;
    bool fly = false;
    bool fly_altura = false;
    bool speed_x50 = false;
    bool wallhack = false;
    bool no_recoil = false;
} cfg;

// --- [ PROFESSIONAL OFFSETS LIST ] ---
namespace Offsets {
    // Global Engine
    uintptr_t GWorld                = 0x76A8B40;
    uintptr_t GNames                = 0x75B2C10;
    
    // Actor & Controller
    uintptr_t LocalPlayer           = 0x38;
    uintptr_t PlayerController      = 0x30;
    uintptr_t Pawn                  = 0x420;
    
    // Movement Component
    uintptr_t CharacterMovement     = 0x320;
    uintptr_t MaxWalkSpeed          = 0x1A0;
    uintptr_t GravityScale          = 0x300;
    uintptr_t JumpZVelocity         = 0x1BC;
    
    // Combat & Physics
    uintptr_t RootComponent         = 0x1A0;
    uintptr_t RelativeLocation      = 0x128;
    uintptr_t SetActorLocation      = 0x78C3D40;
    uintptr_t SetControlRotation    = 0x76B2A10;
    uintptr_t GetBulletLocation     = 0x75A1B20;
    uintptr_t bActorEnableCollision = 0x5C;
    
    // Stats
    uintptr_t Health                = 0x1B8;
    uintptr_t Mesh                  = 0x320;
    uintptr_t BoneArray             = 0x5D8;
}

// --- [ UI WIDGET: MODERN ANDROID TOGGLE ] ---
void DrawVipToggle(const char* label, bool* v, ImU32 activeColor) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return;

    const ImGuiID id = window->GetID(label);
    ImVec2 p = window->DC.CursorPos;
    float width = ImGui::GetContentRegionAvail().x;
    float height = 55.0f;
    const ImRect bb(p, ImVec2(p.x + width, p.y + height));
    
    ImGui::ItemSize(bb);
    if (!ImGui::ItemAdd(bb, id)) return;

    bool hovered, held;
    if (ImGui::ButtonBehavior(bb, id, &hovered, &held)) *v = !(*v);

    ImDrawList* draw = window->DrawList;
    float radius = height * 0.5f;

    // Background & Border
    draw->AddRect(p, ImVec2(p.x + width, p.y + height), activeColor, radius, 0, 2.5f);
    draw->AddRectFilled(p, ImVec2(p.x + width, p.y + height), ImColor(15, 15, 15, 220), radius);
    
    // Label Text
    draw->AddText(ImVec2(p.x + 25, p.y + height/2 - 10), ImColor(255, 255, 255), label);

    // Switch Slot
    float sw_w = 70.0f, sw_h = 35.0f;
    ImVec2 sw_p(p.x + width - sw_w - 15, p.y + height/2 - sw_h/2);
    draw->AddRectFilled(sw_p, ImVec2(sw_p.x + sw_w, sw_p.y + sw_h), *v ? activeColor : ImColor(60, 60, 60), sw_h/2);
    
    // Knob
    float knob_pos_x = *v ? (sw_p.x + sw_w - 18) : (sw_p.x + 18);
    draw->AddCircleFilled(ImVec2(knob_pos_x, sw_p.y + sw_h/2), 12.0f, ImColor(255, 255, 255));
}

// --- [ MAIN MENU RENDER ] ---
void RenderMonalisaMenu() {
    ImGui::SetNextWindowSize(ImVec2(550, 850));
    if (ImGui::Begin("MONALISA_ULTIMATE_FREE", nullptr, ImGuiWindowFlags_NoTitleBar)) {
        
        ImGui::TextColored(ImColor(255, 255, 0), "MONALISA PROJECT - DESTROYER EDITION");
        ImGui::Separator();
        ImGui::Spacing();

        // --- [ MOVEMENT SECTION ] ---
        DrawVipToggle("Air Walk", &cfg.air, ImColor(0, 255, 255)); ImGui::Spacing();
        DrawVipToggle("Under Map", &cfg.under, ImColor(0, 255, 255)); ImGui::Spacing();
        DrawVipToggle("Ninja Run", &cfg.ninja, ImColor(255, 0, 255)); ImGui::Spacing();
        DrawVipToggle("Fly Hack", &cfg.fly, ImColor(0, 255, 0)); ImGui::Spacing();
        DrawVipToggle("Fly Altura", &cfg.fly_altura, ImColor(0, 200, 0)); ImGui::Spacing();
        DrawVipToggle("Speed X50", &cfg.speed_x50, ImColor(255, 255, 255)); ImGui::Spacing();

        // --- [ COMBAT SECTION ] ---
        DrawVipToggle("AimKill VIP", &cfg.aimkill_vi, ImColor(255, 50, 50)); ImGui::Spacing();
        DrawVipToggle("AimKill Silent", &cfg.aim_kill, ImColor(255, 0, 0)); ImGui::Spacing();
        DrawVipToggle("TeleKill", &cfg.telekill, ImColor(255, 100, 0)); ImGui::Spacing();
        DrawVipToggle("No Recoil", &cfg.no_recoil, ImColor(255, 200, 0)); ImGui::Spacing();

        // --- [ MISC SECTION ] ---
        DrawVipToggle("Ghost Mode", &cfg.ghost, ImColor(100, 255, 100)); ImGui::Spacing();
        DrawVipToggle("Fake Lag", &cfg.fake_lag, ImColor(150, 150, 150)); ImGui::Spacing();
        DrawVipToggle("Wallhack (Lines)", &cfg.wallhack, ImColor(255, 255, 0));

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Active Members: 93 | Version: 1.0.2");
        
    }
    ImGui::End();
}
