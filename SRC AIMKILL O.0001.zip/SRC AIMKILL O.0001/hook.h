// --- hooks.h ---
#pragma once
#include "memory.h"
#include "offset.h"

namespace Hooks {
    void ApplyAimKill(uintptr_t base, bool active) {
        if (active) {
            // Force Bullet to Target Offset
            Memory::PatchHex(base + Offsets::GetBulletLocation, "200080D2C0035FD6"); 
        } else {
            // Original Opcode (Example)
            Memory::PatchHex(base + Offsets::GetBulletLocation, "F44FBEA9FD7B01A9");
        }
    }

    void ApplySpeed(uintptr_t base, float multiplier) {
        // Direct Write to Offset within PlayerController -> CharacterMovement
        uintptr_t playerController = *(uintptr_t*)(base + Offsets::GWorld + Offsets::PlayerController);
        if (playerController) {
            uintptr_t pawn = *(uintptr_t*)(playerController + Offsets::Pawn);
            if (pawn) {
                uintptr_t moveComp = *(uintptr_t*)(pawn + Offsets::CharacterMovement);
                if (moveComp) {
                    float speed = 600.0f * multiplier;
                    Memory::Write(moveComp + Offsets::MaxWalkSpeed, &speed, sizeof(float));
                }
            }
        }
    }
}

// --- destroyer.cpp (The "แจกกระจาย" Logic) ---
#include "hooks.h"
#include "config.h"

void RunDestroyerLogic(uintptr_t base) {
    // Movement Logic
    if (cfg.speed_x50) Hooks::ApplySpeed(base, 50.0f);
    if (cfg.air) Memory::PatchHex(base + 0xDEADBEEF, "000080D2C0035FD6"); // Custom AirWalk Offset
    
    // Combat Logic
    Hooks::ApplyAimKill(base, cfg.aim_kill);
    
    // Telekill Logic (Loop Players)
    if (cfg.telekill) {
        uintptr_t world = *(uintptr_t*)(base + Offsets::GWorld);
        // ... Entity Loop Logic to SetActorLocation ...
    }
}

// --- CMakeLists.txt ---
cmake_minimum_required(VERSION 3.10.2)
project("MonalisaFree")

add_library(Monalisa SHARED
    main.cpp
    menu.cpp
    imgui/imgui.cpp
    imgui/imgui_draw.cpp
    imgui/imgui_widgets.cpp
    imgui/imgui_tables.cpp
    imgui/imgui_demo.cpp
    imgui/backends/imgui_impl_android.h
    imgui/backends/imgui_impl_android.cpp
)

target_link_libraries(Monalisa android log)

// --- Build.sh (Script สำหรับสายโมบาย) ---
# ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=./Android.mk
# หรือใช้ผ่าน Android Studio สั่ง Sync Project with Gradle Files
