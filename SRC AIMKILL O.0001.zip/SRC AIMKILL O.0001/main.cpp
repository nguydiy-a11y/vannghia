#include <pthread.h>
#include <jni.h>
#include "config.h"
#include "offset.h"
#include "memory.h"

void* HackThread(void*) {
    uintptr_t base = 0;
    while (!(base = Memory::GetBaseAddress("libil2cpp.so"))) {
        sleep(1);
    }

    while (true) {
        if (cfg.air) {
            Memory::PatchHex(base + Offsets::GravityScale, "000080D2C0035FD6");
        }
        if (cfg.ninja) {
            Memory::PatchHex(base + Offsets::MaxWalkSpeed, "400680D2C0035FD6");
        }
        if (cfg.ghost) {
            Memory::PatchHex(base + Offsets::bActorEnableCollision, "1F2003D5");
        }
        if (cfg.fly) {
            Memory::PatchHex(base + Offsets::JumpZVelocity, "0000A0D2C0035FD6");
        }
        if (cfg.aim_kill) {
            // Logic for AimKill 
        }
        
        usleep(500000); 
    }
    return nullptr;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    JNIEnv* env;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    pthread_t ptid;
    pthread_create(&ptid, NULL, HackThread, NULL);

    return JNI_VERSION_1_6;
}
