#include "imgui.h"
#include "imgui_internal.h"
#include "config.h"

void DrawAndroidToggle(const char* label, bool* v, ImU32 activeColor) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return;

    const ImGuiID id = window->GetID(label);
    ImVec2 p = window->DC.CursorPos;
    float width = ImGui::GetContentRegionAvail().x;
    float height = 55.0f;
    const ImRect bb(p, ImVec2(p.x + width, p.y + height));

    ImGui::ItemSize(bb);
    if (!ImGui::ItemAdd(bb, id)) return;

    bool hovered, held;
    if (ImGui::ButtonBehavior(bb, id, &hovered, &held)) *v = !(*v);

    ImDrawList* draw = window->DrawList;
    float radius = height * 0.5f;

    draw->AddRect(p, ImVec2(p.x + width, p.y + height), activeColor, radius, 0, 2.5f);
    draw->AddRectFilled(p, ImVec2(p.x + width, p.y + height), ImColor(15, 15, 15, 220), radius);
    draw->AddText(ImVec2(p.x + 25, p.y + height / 2 - 10), ImColor(255, 255, 255), label);

    float sw_w = 70.0f, sw_h = 35.0f;
    ImVec2 sw_p(p.x + width - sw_w - 15, p.y + height / 2 - sw_h / 2);
    draw->AddRectFilled(sw_p, ImVec2(sw_p.x + sw_w, sw_p.y + sw_h), *v ? activeColor : ImColor(60, 60, 60), sw_h / 2);

    float knob_pos_x = *v ? (sw_p.x + sw_w - 18) : (sw_p.x + 18);
    draw->AddCircleFilled(ImVec2(knob_pos_x, sw_p.y + sw_h / 2), 12.0f, ImColor(255, 255, 255));
}

void RenderMonalisaMenu() {
    ImGui::SetNextWindowSize(ImVec2(500, 750), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("MONALISA_VIP", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize)) {
        
        ImGui::TextColored(ImColor(255, 255, 0), "MONALISA PROJECT - FREE VERSION");
        ImGui::Separator();
        ImGui::Spacing();

        DrawAndroidToggle("Air Walk", &cfg.air, ImColor(0, 255, 255)); ImGui::Spacing();
        DrawAndroidToggle("Under Map", &cfg.under, ImColor(0, 255, 255)); ImGui::Spacing();
        DrawAndroidToggle("Ninja Run", &cfg.ninja, ImColor(255, 0, 255)); ImGui::Spacing();
        DrawAndroidToggle("Teleport Vi", &cfg.tele_vi, ImColor(255, 165, 0)); ImGui::Spacing();
        DrawAndroidToggle("Telekill", &cfg.telekill, ImColor(255, 0, 0)); ImGui::Spacing();
        DrawAndroidToggle("AimKill VIP", &cfg.aimkill_vi, ImColor(255, 0, 100)); ImGui::Spacing();
        DrawAndroidToggle("AimKill Silent", &cfg.aim_kill, ImColor(255, 0, 0)); ImGui::Spacing();
        DrawAndroidToggle("Fake Lag", &cfg.fake_lag, ImColor(255, 0, 0)); ImGui::Spacing();
        DrawAndroidToggle("Ghost Mode", &cfg.ghost, ImColor(0, 255, 0)); ImGui::Spacing();
        DrawAndroidToggle("Fly Hack", &cfg.fly, ImColor(0, 255, 0)); ImGui::Spacing();
        DrawAndroidToggle("Fly Altura", &cfg.fly_altura, ImColor(255, 0, 0));

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Status: Online | Members: 93");
    }
    ImGui::End();
}
