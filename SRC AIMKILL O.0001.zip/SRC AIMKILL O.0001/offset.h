#pragma once
#include <cstdint>

namespace Offsets {
    // --- [ Global Engine ] ---
    uintptr_t GWorld                = 0x76A8B40;
    uintptr_t GNames                = 0x75B2C10;
    
    // --- [ Actor & Player ] ---
    uintptr_t LocalPlayer           = 0x38;
    uintptr_t PlayerController      = 0x30;
    uintptr_t PlayerCameraManager   = 0x340;
    uintptr_t Pawn                  = 0x420; // AcknowledgedPawn
    uintptr_t RootComponent         = 0x1A0;
    uintptr_t RelativeLocation      = 0x128;
    uintptr_t RelativeRotation      = 0x140;
    
    // --- [ Movement Component ] ---
    uintptr_t CharacterMovement     = 0x320;
    uintptr_t MaxWalkSpeed          = 0x1A0;
    uintptr_t MaxAcceleration       = 0x1AC;
    uintptr_t GravityScale          = 0x300;
    uintptr_t JumpZVelocity         = 0x1BC;
    
    // --- [ Combat & Aim ] ---
    uintptr_t Mesh                  = 0x320;
    uintptr_t BoneArray             = 0x5D8;
    uintptr_t ActorHealth           = 0x1B8;
    uintptr_t RemoteViewPitch       = 0x242;
    uintptr_t ControlRotation       = 0x2A8;
    
    // --- [ Functions (Pattern Scan/Offsets) ] ---
    uintptr_t SetControlRotation    = 0x76B2A10;
    uintptr_t SetActorLocation      = 0x78C3D40;
    uintptr_t GetMuzzleLocation     = 0x8F077A0;
    uintptr_t LineOfSightTo         = 0x3A2A1B0;
    
    // --- [ Misc ] ---
    uintptr_t bActorEnableCollision = 0x5C;
    uintptr_t TeamID                = 0x670;
}
