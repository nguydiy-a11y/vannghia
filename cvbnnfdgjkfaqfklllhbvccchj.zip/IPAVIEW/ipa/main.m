#import <Foundation/Foundation.h>
#import "CYAppDelegate.h"

int main(int argc, char *argv[]) {
	@autoreleasepool {
		return UIApplicationMain(argc, argv, nil, NSStringFromClass(CYAppDelegate.class));
	}
}
