#ifndef hook_h
#define hook_h

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>

bool hook(void *o[], void *n[], int c);
bool unhook();

#ifdef __cplusplus
}
#endif

#endif /* hook_h */
